import { todayISO } from '../../lib/lifeStore.js'

export const currentYear = new Date().getFullYear()

export const emptyWorker = {
  type: '1099',
  name: '',
  ssn: '',
  address: '',
  work_pay: '',
  tips: '',
  tax_year: currentYear,
  notes: '',
}

export const emptyIncome = {
  source: '',
  category: 'salon_income',
  amount: '',
  record_date: todayISO(),
  notes: '',
}

export const taxCopy = {
  vi: {
    title: 'Tổng kết cuối năm',
    sub: 'Dành cho chủ tiệm và business nhỏ: ghi tiền trả thợ, tiền tip, income và chi tiêu để cuối năm xuất file đưa cho người làm thuế. App chỉ gom dữ liệu, không tự làm form thuế.',
    workers: 'Hồ sơ thợ / nhân viên',
    addWorker: 'Thêm thợ / nhân viên',
    income: 'Income kinh doanh',
    addIncome: 'Thêm income',
    expenses: 'Chi tiêu kinh doanh',
    exportWorkers: 'Xuất thợ CSV',
    exportIncome: 'Xuất income CSV',
    exportExpenses: 'Xuất chi tiêu CSV',
    exportPdf: 'Xuất PDF tổng kết',
    save: 'Lưu', close: 'Đóng', delete: 'Xóa', type: 'Loại', name: 'Tên thợ / nhân viên',
    ssn: 'SSN hoặc EIN', address: 'Địa chỉ', workPay: 'Tiền làm', tips: 'Tiền tip', total: 'Tổng cộng',
    year: 'Năm thuế', notes: 'Ghi chú', source: 'Nguồn income', category: 'Loại income', amount: 'Số tiền', date: 'Ngày',
    emptyWorkers: 'Chưa có thợ hoặc nhân viên nào.', emptyIncome: 'Chưa có income kinh doanh nào.', emptyExpenses: 'Chưa có chi tiêu kinh doanh trong năm nay.',
    businessIncome: 'Income kinh doanh', workerTotal: 'Tiền trả thợ', businessExpenseTotal: 'Chi tiêu kinh doanh', netBusiness: 'Ước tính còn lại',
    warning: 'Thông tin SSN/EIN rất nhạy cảm. Chỉ nhập khi thật sự cần đưa cho người làm thuế. App này chỉ hỗ trợ gom dữ liệu, không tư vấn thuế.',
    runSql: 'Nếu trang này báo thiếu bảng/cột, chạy file supabase/migration_004_tax_worker_income.sql trong Supabase trước.',
    incomeCategories: { salon_income: 'Income tiệm nail', booth_rent: 'Booth rent', uber: 'Uber', doordash: 'DoorDash', other_business: 'Kinh doanh khác' },
  },
  en: {
    title: 'Year-End Records',
    sub: 'For salon owners and small-business users: record worker pay, tips, business income, and expenses so you can export clean files for your tax preparer. The app organizes data; it does not prepare tax forms.',
    workers: 'Worker records', addWorker: 'Add worker', income: 'Business income', addIncome: 'Add income', expenses: 'Business expenses',
    exportWorkers: 'Export workers CSV', exportIncome: 'Export income CSV', exportExpenses: 'Export expenses CSV', exportPdf: 'Export PDF summary',
    save: 'Save', close: 'Cancel', delete: 'Delete', type: 'Type', name: 'Worker / employee name', ssn: 'SSN or EIN', address: 'Address',
    workPay: 'Work pay', tips: 'Tips', total: 'Total', year: 'Tax year', notes: 'Notes', source: 'Income source', category: 'Income type', amount: 'Amount', date: 'Date',
    emptyWorkers: 'No worker records yet.', emptyIncome: 'No business income yet.', emptyExpenses: 'No business expenses recorded this year.',
    businessIncome: 'Business income', workerTotal: 'Worker payments', businessExpenseTotal: 'Business expenses', netBusiness: 'Estimated net',
    warning: 'SSN/EIN is sensitive. Only enter it if your tax preparer needs it. This app organizes records; it does not provide tax advice.',
    runSql: 'If this page says tables/columns are missing, run supabase/migration_004_tax_worker_income.sql in Supabase first.',
    incomeCategories: { salon_income: 'Nail salon income', booth_rent: 'Booth rent', uber: 'Uber', doordash: 'DoorDash', other_business: 'Other business' },
  },
}
