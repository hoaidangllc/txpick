import React from 'react'
import ReactDOM from 'react-dom/client'
import { BrowserRouter } from 'react-router-dom'
import App from './App.jsx'
import { LanguageProvider } from './contexts/LanguageContext.jsx'
import { AuthProvider } from './contexts/AuthContext.jsx'
import { ElderModeProvider } from './contexts/ElderModeContext.jsx'
import './index.css'
import { registerPWA } from './lib/pwa.js'

if (import.meta.env.PROD) {
  registerPWA()
}

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <BrowserRouter>
      <LanguageProvider>
        <ElderModeProvider>
          <AuthProvider>
            <App />
          </AuthProvider>
        </ElderModeProvider>
      </LanguageProvider>
    </BrowserRouter>
  </React.StrictMode>,
)
